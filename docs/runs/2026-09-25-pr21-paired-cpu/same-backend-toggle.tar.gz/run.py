import json
import os
from pathlib import Path
import statistics
import time
import psycopg2

out = Path('/home/reing/projects/fts0/PIN/.artifacts/pr21-paired-toggle-20260925')
cases = {
    'rare': ('rareplanet', 'rareplanet'),
    'selective_and': ('alpha AND rareplanet', 'alpha & rareplanet'),
    'and': ('alpha AND beta', 'alpha & beta'),
    'or': ('alpha OR rareplanet', 'alpha | rareplanet'),
}
orders = [('off', 'on', 'gin'), ('gin', 'on', 'off'), ('on', 'off', 'gin'), ('gin', 'off', 'on')]
conn = psycopg2.connect(application_name='pin_pr21_paired_toggle')
conn.autocommit = True
rows = []
with conn.cursor() as cur:
    for setting in (
        'enable_seqscan=off', 'enable_bitmapscan=on', 'enable_indexscan=off',
        'enable_indexonlyscan=off', 'max_parallel_workers_per_gather=0',
        'jit=off', 'pin.enable_count_fastpath=off', 'pin.enable_count_vm=off',
        'pin.enable_exact_bitmap=on', 'pin.enable_grouped_scan=on',
        'pin.enable_frontier_anchors=on', 'pin.enable_grouped_storage=off',
        'plan_cache_mode=force_generic_plan', "statement_timeout='120s'",
    ):
        cur.execute('SET ' + setting)
    cur.execute('SELECT pin.build_revision(), pg_backend_pid(), current_setting(\'pin.enable_owner_frontier\')')
    revision, pid, starting_gate = cur.fetchone()
    assert revision == '2a5818fd66cfe5a5e9622d19798f2fee61ef7d37', revision
    cur.execute('SELECT max(id) FROM public.pin_g6_bench')
    first = cur.fetchone()[0] + 1
    cur.execute("INSERT INTO public.pin_g6_bench SELECT %s + i, 'alpha beta rareplanet newterm' FROM generate_series(0,4095) AS i", (first,))
    cur.execute('SELECT count(*) FROM public.pin_g6_bench')
    count = cur.fetchone()[0]
    for case, (pin, gin) in cases.items():
        cur.execute(f"PREPARE p_{case} AS SELECT count(*) FROM ONLY public.pin_g6_bench WHERE body OPERATOR(pin.@@@) pin.parse_query(%s)", (pin,))
        cur.execute(f"PREPARE g_{case} AS SELECT count(*) FROM ONLY public.pin_g6_bench WHERE to_tsvector('simple', body) @@ to_tsquery('simple', %s)", (gin,))
    proc = Path(f'/proc/{pid}/schedstat')
    def cpu_ns():
        return int(proc.read_text().split()[0])
    for case in cases:
        for rep, order in enumerate(orders):
            for mode in order:
                cur.execute('SET pin.enable_owner_frontier=' + ('on' if mode == 'on' else 'off'))
                statement = f'EXECUTE {"g" if mode == "gin" else "p"}_{case}'
                cur.execute('EXPLAIN (FORMAT JSON) ' + statement)
                plan = cur.fetchone()[0][0]['Plan']
                names = []
                stack = [plan]
                while stack:
                    node = stack.pop()
                    if node['Node Type'] == 'Bitmap Index Scan':
                        names.append(node['Index Name'])
                    stack.extend(node.get('Plans', []))
                assert names == [f'pin_g6_bench_body_{"gin"}' if mode == 'gin' else 'pin_g6_bench_body'], (case, mode, names)
                for _ in range(10):
                    cur.execute(statement)
                    cur.fetchone()
                start = cpu_ns()
                wall_start = time.perf_counter_ns()
                for _ in range(100):
                    cur.execute(statement)
                    result = cur.fetchone()[0]
                wall_ns = time.perf_counter_ns() - wall_start
                cpu = cpu_ns() - start
                record = {'case': case, 'rep': rep, 'mode': mode, 'queries': 100,
                          'rows': result, 'cpu_us_per_query': cpu / 100_000,
                          'wall_us_per_query': wall_ns / 100_000,
                          'index': names[0]}
                rows.append(record)
                (out / 'results.json').write_text(json.dumps({'revision': revision, 'pid': pid,
                    'starting_gate': starting_gate, 'first_added_id': first, 'added_rows': 4096,
                    'total_rows': count, 'orders': orders, 'results': rows}, indent=2) + '\n')
                print(case, rep, mode, round(record['cpu_us_per_query'], 1), flush=True)
conn.close()
