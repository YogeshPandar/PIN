SET pin.enable_frontier_anchors = off;
SET pin.enable_owner_frontier = off;
CREATE ROLE gc_reader NOLOGIN; GRANT SELECT ON g9_count_docs TO gc_reader; GRANT USAGE ON SCHEMA pin TO gc_reader; ALTER TABLE g9_count_docs ENABLE ROW LEVEL SECURITY; CREATE POLICY gc_even ON g9_count_docs USING (id%2=0);
