SET pin.enable_frontier_anchors = off;
SET pin.enable_owner_frontier = off;

SET enable_seqscan=off; SET enable_bitmapscan=on;
SET enable_indexscan=off; SET enable_indexonlyscan=off;
SET max_parallel_workers_per_gather=0; SET max_parallel_maintenance_workers=0;
SET pin.parallel_count_workers=0; SET jit=off;
SET pin.enable_count_fastpath=on; SET pin.enable_count_vm=on;
SET pin.enable_grouped_count=on; SET pin.enable_grouped_scan=on;
SET pin.enable_grouped_page_visibility=off;
SET pin.enable_exact_bitmap=on; SET work_mem='4MB';
SET maintenance_work_mem='4MB';

        SET pin.enable_grouped_storage=on;
        CREATE TABLE g9_count_reuse(id bigint,body text,notes integer)
            WITH (autovacuum_enabled=false,fillfactor=50);
        CREATE INDEX ON g9_count_reuse USING pin(body);
        INSERT INTO g9_count_reuse VALUES(1,'alpha',0),(2,'alpha bravo',0);
        INSERT INTO g9_count_reuse SELECT i,'filler',0 FROM generate_series(10,73) i;
        CREATE INDEX ON g9_count_reuse USING gin(to_tsvector('simple',body));
        VACUUM (INDEX_CLEANUP ON,PARALLEL 0) g9_count_reuse;
        CREATE TEMP TABLE gc_old AS SELECT ctid old_tid FROM g9_count_reuse WHERE id=1;
        DELETE FROM g9_count_reuse WHERE id=1;
        SET pin.enable_grouped_storage=off; SET pin.enable_grouped_scan=off;
        VACUUM (INDEX_CLEANUP ON,PARALLEL 0) g9_count_reuse;
        INSERT INTO g9_count_reuse VALUES(3,'bravo',0);
        DO $$ BEGIN
          IF NOT EXISTS (SELECT FROM g9_count_reuse n,gc_old o WHERE n.id=3 AND n.ctid=o.old_tid)
          THEN RAISE EXCEPTION 'test did not reuse the retired heap slot'; END IF;
        END $$;
    
