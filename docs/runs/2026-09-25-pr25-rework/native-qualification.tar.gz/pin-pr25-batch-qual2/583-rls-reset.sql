SET pin.enable_frontier_anchors = off;
SET pin.enable_owner_frontier = off;
ALTER TABLE g9_count_docs DISABLE ROW LEVEL SECURITY;
