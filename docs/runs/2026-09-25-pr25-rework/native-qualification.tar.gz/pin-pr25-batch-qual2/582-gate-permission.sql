SET pin.enable_frontier_anchors = off;
SET pin.enable_owner_frontier = off;
SET ROLE gc_reader; SET pin.enable_grouped_count=on;
