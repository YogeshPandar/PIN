SET pin.enable_frontier_anchors = off;
SET pin.enable_owner_frontier = off;

SET enable_seqscan=off; SET enable_bitmapscan=on;
SET enable_indexscan=off; SET enable_indexonlyscan=off;
SET max_parallel_workers_per_gather=0; SET max_parallel_maintenance_workers=0;
SET pin.parallel_count_workers=0; SET jit=off;
SET pin.enable_count_fastpath=on; SET pin.enable_count_vm=on;
SET pin.enable_grouped_count=on; SET pin.enable_grouped_scan=on;
SET pin.enable_grouped_page_visibility=off;
SET pin.enable_exact_bitmap=on; SET work_mem='4MB';
SET maintenance_work_mem='4MB';
SELECT coalesce(json_agg(json_build_array(id,ctid::text) ORDER BY id,ctid),'[]'::json) FROM ONLY g9_count_reuse WHERE to_tsvector('simple',body) @@ to_tsquery('simple','alpha & bravo');
