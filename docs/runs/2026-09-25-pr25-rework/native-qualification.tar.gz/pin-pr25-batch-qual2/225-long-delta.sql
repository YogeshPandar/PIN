SET pin.enable_frontier_anchors = off;
SET pin.enable_owner_frontier = off;

SET enable_seqscan=off; SET enable_bitmapscan=on;
SET enable_indexscan=off; SET enable_indexonlyscan=off;
SET max_parallel_workers_per_gather=0; SET max_parallel_maintenance_workers=0;
SET pin.parallel_count_workers=0; SET jit=off;
SET pin.enable_count_fastpath=on; SET pin.enable_count_vm=on;
SET pin.enable_grouped_count=on; SET pin.enable_grouped_scan=on;
SET pin.enable_grouped_page_visibility=off;
SET pin.enable_exact_bitmap=on; SET work_mem='4MB';
SET maintenance_work_mem='4MB';
INSERT INTO g9_count_docs(id,body) SELECT g,concat(CASE WHEN g%4<3 THEN 'alpha ' ELSE '' END,CASE WHEN g%3<2 THEN 'bravo charlie ' ELSE 'charlie bravo ' END,CASE WHEN g%97=0 THEN 'uncommon ' ELSE '' END,translate(md5((g%4093)::text),'0123456789','ghijklmnop'),' ',repeat('delta echo ',1+(g%13)::int), '') FROM generate_series(1400,2010) g;
