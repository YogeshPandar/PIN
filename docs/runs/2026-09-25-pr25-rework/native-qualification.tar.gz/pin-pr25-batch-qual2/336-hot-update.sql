SET pin.enable_frontier_anchors = off;
SET pin.enable_owner_frontier = off;

SET enable_seqscan=off; SET enable_bitmapscan=on;
SET enable_indexscan=off; SET enable_indexonlyscan=off;
SET max_parallel_workers_per_gather=0; SET max_parallel_maintenance_workers=0;
SET pin.parallel_count_workers=0; SET jit=off;
SET pin.enable_count_fastpath=on; SET pin.enable_count_vm=on;
SET pin.enable_grouped_count=on; SET pin.enable_grouped_scan=on;
SET pin.enable_grouped_page_visibility=off;
SET pin.enable_exact_bitmap=on; SET work_mem='4MB';
SET maintenance_work_mem='4MB';
BEGIN; UPDATE g9_count_docs SET notes=notes+1 WHERE id<=10; SELECT n_tup_hot_upd FROM pg_stat_xact_user_tables WHERE relid='g9_count_docs'::regclass; COMMIT;
