SET pin.enable_frontier_anchors = off;
SET pin.enable_owner_frontier = off;

SET enable_seqscan=off; SET enable_bitmapscan=on;
SET enable_indexscan=off; SET enable_indexonlyscan=off;
SET max_parallel_workers_per_gather=0; SET max_parallel_maintenance_workers=0;
SET pin.parallel_count_workers=0; SET jit=off;
SET pin.enable_count_fastpath=on; SET pin.enable_count_vm=on;
SET pin.enable_grouped_count=on; SET pin.enable_grouped_scan=on;
SET pin.enable_grouped_page_visibility=off;
SET pin.enable_exact_bitmap=on; SET work_mem='4MB';
SET maintenance_work_mem='4MB';
EXPLAIN (FORMAT JSON) SELECT count(id) FROM ONLY g9_count_docs WHERE body OPERATOR(pin.@@@) pin.parse_query('alpha AND bravo');
