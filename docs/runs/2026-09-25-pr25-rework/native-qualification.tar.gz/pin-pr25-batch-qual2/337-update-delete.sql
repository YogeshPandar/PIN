SET pin.enable_frontier_anchors = off;
SET pin.enable_owner_frontier = off;
UPDATE g9_count_docs SET body='bravo replacement' WHERE id%17=0; DELETE FROM g9_count_docs WHERE id%19=0;
