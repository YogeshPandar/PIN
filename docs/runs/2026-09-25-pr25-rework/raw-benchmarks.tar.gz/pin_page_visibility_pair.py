import json, sys, statistics
from pathlib import Path
sys.path.insert(0, '/home/reing/projects/fts0/PIN/tools')
from g9_count_bench import Session, cpu_read, cpu_delta, sql_for, settings, check_plan, TABLE
p=Path('/tmp/pin-pr25-page-pair.json')
s=Session(Path('/usr/lib/postgresql/18/bin/psql'),Path('/tmp/pin-pr25-page-pair2.stderr'),'pin_grouped_enabled',timeout=3600)
with s:
 s.execute("SET statement_timeout='3500s'; SET pin.enable_grouped_storage=on; SET pin.enable_grouped_delta_seal=on;")
 rev=s.execute('SELECT pin.build_revision();')
 s.execute(f'UPDATE {TABLE} SET notes=notes+1 WHERE id%103=0;')
 pid=int(s.execute('SELECT pg_backend_pid();'))
 out={'revision':rev,'source':'same backend and same mutated table, 6 paired blocks x 10 queries, warm cache','pid':pid,'records':[]}
 for case in ('broad_and_count','broad_or_count'):
  settings(s,'pin_grouped')
  sql=sql_for(case,'pin_grouped')
  s.execute('PREPARE measured_pin_grouped AS '+sql)
  expected=None
  for mode in ('off','on'):
   s.execute('SET pin.enable_grouped_page_visibility='+mode+';')
   got=s.execute('EXECUTE measured_pin_grouped;')
   if expected is None: expected=got
   assert got==expected,(mode,got,expected)
   plan=json.loads(s.execute('EXPLAIN (ANALYZE,BUFFERS,TIMING OFF,FORMAT JSON) EXECUTE measured_pin_grouped;'))
   assert check_plan(plan,'pin_grouped',case,executed=True,require_grouped=True)['grouped_runs']==1
   out.setdefault('plan',{}).setdefault(case,{})[mode]=plan
  for block in range(6):
   for mode in (('off','on') if block%2==0 else ('on','off')):
    s.execute('SET pin.enable_grouped_page_visibility='+mode+';')
    for _ in range(2): assert s.execute('EXECUTE measured_pin_grouped;')==expected
    before=cpu_read(pid)
    for _ in range(10): assert s.execute('EXECUTE measured_pin_grouped;')==expected
    after=cpu_read(pid)
    out['records'].append({'case':case,'block':block,'mode':mode,'cpu':cpu_delta(before,after,10)})
  s.execute('DEALLOCATE measured_pin_grouped;')
 for case in ('broad_and_count','broad_or_count'):
  for mode in ('off','on'):
   a=[r['cpu']['cpu_us_per_query'] for r in out['records'] if r['case']==case and r['mode']==mode]
   out.setdefault('summary',{}).setdefault(case,{})[mode]={'median_cpu_us':statistics.median(a),'samples':a}
 p.write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out['summary'],indent=2))
